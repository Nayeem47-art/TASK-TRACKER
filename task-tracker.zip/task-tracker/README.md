# Task Tracker

A small app built with **Vite + React 19 + TypeScript + Tailwind CSS v4 + shadcn/ui**.

## Run it

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # type-check + production build
```

## Features

- List tasks, search, filter (all / active / done), toggle complete, delete
- Create tasks with title, description and priority
- Task detail page
- Tasks persist in `localStorage`

## Where the required hooks are used

| Hook | Where |
| --- | --- |
| `useState` | `TasksProvider` (task list), list page (filter/search), new-task form (fields + error) |
| `useEffect` | `TasksProvider` (save to localStorage), pages (document title, autofocus, redirect for unknown ids) |
| `useNavigate` | Row click → detail, form submit → new task, Back/Cancel, redirect after delete, 404 "Go home" |

## Adding more shadcn components

`components.json` is configured, so you can run e.g. `npx shadcn@latest add dialog`.
The Button, Input, Textarea, Label, Card and Badge components in `src/components/ui`
are hand-written in the shadcn "new-york" style so the project works out of the box.
