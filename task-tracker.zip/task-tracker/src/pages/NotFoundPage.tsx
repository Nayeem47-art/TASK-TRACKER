import { useNavigate } from "react-router-dom"

import { Button } from "@/components/ui/button"

export default function NotFoundPage() {
  const navigate = useNavigate()
  return (
    <div className="space-y-4 py-16 text-center">
      <h1 className="text-4xl font-bold">404</h1>
      <p className="text-muted-foreground">That page doesn't exist.</p>
      <Button onClick={() => navigate("/")}>Go home</Button>
    </div>
  )
}
