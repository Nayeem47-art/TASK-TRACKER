import { useEffect } from "react"
import { useNavigate, useParams } from "react-router-dom"
import { ArrowLeft, Trash2 } from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { useTasks } from "@/lib/tasks"
import { priorityVariant } from "@/pages/TaskListPage"

export default function TaskDetailPage() {
  const { id } = useParams<{ id: string }>()
  const { tasks, updateTask, deleteTask } = useTasks()
  const navigate = useNavigate()
  const task = tasks.find((t) => t.id === id)

  // useEffect: title follows the task; redirect home if it doesn't exist
  useEffect(() => {
    if (!task) {
      navigate("/", { replace: true })
      return
    }
    document.title = `${task.title} · Task Tracker`
  }, [task, navigate])

  if (!task) return null

  return (
    <div className="mx-auto max-w-xl space-y-4">
      <Button variant="ghost" size="sm" onClick={() => navigate("/")}>
        <ArrowLeft /> Back to tasks
      </Button>
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between gap-4">
            <CardTitle className={cn("text-xl leading-snug", task.done && "line-through text-muted-foreground")}>
              {task.title}
            </CardTitle>
            <Badge variant={priorityVariant[task.priority]} className="capitalize">
              {task.priority}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <p className={task.description ? "" : "text-muted-foreground"}>
            {task.description || "No description."}
          </p>
          <p className="text-muted-foreground">
            Created {new Date(task.createdAt).toLocaleString()} ·{" "}
            {task.done ? "Completed" : "In progress"}
          </p>
        </CardContent>
        <CardFooter className="justify-between">
          <Button variant="outline" onClick={() => updateTask(task.id, { done: !task.done })}>
            {task.done ? "Reopen" : "Mark as done"}
          </Button>
          <Button
            variant="destructive"
            onClick={() => {
              deleteTask(task.id)
              navigate("/")
            }}
          >
            <Trash2 /> Delete
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
