import { useEffect, useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import { Circle, CircleCheck, Trash2 } from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"
import { useTasks, type Priority } from "@/lib/tasks"

type Filter = "all" | "active" | "done"

export const priorityVariant: Record<Priority, "default" | "secondary" | "destructive"> = {
  low: "secondary",
  medium: "default",
  high: "destructive",
}

export default function TaskListPage() {
  const { tasks, updateTask, deleteTask } = useTasks()
  const navigate = useNavigate()

  // useState: UI state for filtering and searching
  const [filter, setFilter] = useState<Filter>("all")
  const [query, setQuery] = useState("")

  const remaining = tasks.filter((t) => !t.done).length

  // useEffect: keep the browser tab title in sync with the data
  useEffect(() => {
    document.title = remaining ? `(${remaining}) Task Tracker` : "Task Tracker"
  }, [remaining])

  const visible = tasks.filter((t) => {
    if (filter === "active" && t.done) return false
    if (filter === "done" && !t.done) return false
    return t.title.toLowerCase().includes(query.trim().toLowerCase())
  })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Your tasks</h1>
        <p className="text-sm text-muted-foreground">
          {remaining} remaining · {tasks.length - remaining} completed
        </p>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row">
        <Input
          placeholder="Search tasks…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <div className="flex gap-1">
          {(["all", "active", "done"] as Filter[]).map((f) => (
            <Button
              key={f}
              size="sm"
              variant={filter === f ? "default" : "outline"}
              onClick={() => setFilter(f)}
              className="capitalize"
            >
              {f}
            </Button>
          ))}
        </div>
      </div>

      {visible.length === 0 ? (
        <Card>
          <CardContent className="py-6 text-center text-sm text-muted-foreground">
            {tasks.length === 0 ? (
              <>
                No tasks yet.{" "}
                <Link to="/new" className="font-medium text-foreground underline">
                  Create your first one
                </Link>
                .
              </>
            ) : (
              "No tasks match your filter."
            )}
          </CardContent>
        </Card>
      ) : (
        <ul className="space-y-2">
          {visible.map((task) => (
            <li key={task.id}>
              <Card className="py-3">
                <CardContent className="flex items-center gap-3">
                  <Button
                    variant="ghost"
                    size="icon"
                    aria-label={task.done ? "Mark as not done" : "Mark as done"}
                    onClick={() => updateTask(task.id, { done: !task.done })}
                  >
                    {task.done ? (
                      <CircleCheck className="text-green-600" />
                    ) : (
                      <Circle className="text-muted-foreground" />
                    )}
                  </Button>

                  {/* useNavigate: the row opens the detail route */}
                  <button
                    type="button"
                    onClick={() => navigate(`/tasks/${task.id}`)}
                    className="min-w-0 flex-1 text-left"
                  >
                    <p className={cn("truncate font-medium", task.done && "text-muted-foreground line-through")}>
                      {task.title}
                    </p>
                    {task.description && (
                      <p className="truncate text-sm text-muted-foreground">{task.description}</p>
                    )}
                  </button>

                  <Badge variant={priorityVariant[task.priority]} className="capitalize">
                    {task.priority}
                  </Badge>
                  <Button
                    variant="ghost"
                    size="icon"
                    aria-label="Delete task"
                    onClick={() => deleteTask(task.id)}
                  >
                    <Trash2 className="text-muted-foreground" />
                  </Button>
                </CardContent>
              </Card>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
