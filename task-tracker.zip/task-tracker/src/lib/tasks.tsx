import { createContext, useContext, useEffect, useState, type ReactNode } from "react"

export type Priority = "low" | "medium" | "high"

export interface Task {
  id: string
  title: string
  description: string
  priority: Priority
  done: boolean
  createdAt: number
}

interface TasksContextValue {
  tasks: Task[]
  addTask: (input: Pick<Task, "title" | "description" | "priority">) => string
  updateTask: (id: string, patch: Partial<Omit<Task, "id">>) => void
  deleteTask: (id: string) => void
}

const STORAGE_KEY = "task-tracker:tasks"

function loadTasks(): Task[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    return raw ? (JSON.parse(raw) as Task[]) : []
  } catch {
    return []
  }
}

const TasksContext = createContext<TasksContextValue | null>(null)

export function TasksProvider({ children }: { children: ReactNode }) {
  // useState: the task list (lazy-initialised from localStorage)
  const [tasks, setTasks] = useState<Task[]>(loadTasks)

  // useEffect: persist to localStorage whenever tasks change
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks))
    } catch {
      /* storage unavailable – keep working in memory */
    }
  }, [tasks])

  const addTask: TasksContextValue["addTask"] = (input) => {
    const id = crypto.randomUUID()
    setTasks((prev) => [{ ...input, id, done: false, createdAt: Date.now() }, ...prev])
    return id
  }

  const updateTask: TasksContextValue["updateTask"] = (id, patch) =>
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, ...patch } : t)))

  const deleteTask: TasksContextValue["deleteTask"] = (id) =>
    setTasks((prev) => prev.filter((t) => t.id !== id))

  return (
    <TasksContext.Provider value={{ tasks, addTask, updateTask, deleteTask }}>
      {children}
    </TasksContext.Provider>
  )
}

export function useTasks() {
  const ctx = useContext(TasksContext)
  if (!ctx) throw new Error("useTasks must be used inside <TasksProvider>")
  return ctx
}
