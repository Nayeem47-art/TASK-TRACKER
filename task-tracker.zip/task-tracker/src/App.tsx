import { Link, Route, Routes } from "react-router-dom"
import { CheckSquare, Plus } from "lucide-react"

import { Button } from "@/components/ui/button"
import TaskListPage from "@/pages/TaskListPage"
import NewTaskPage from "@/pages/NewTaskPage"
import TaskDetailPage from "@/pages/TaskDetailPage"
import NotFoundPage from "@/pages/NotFoundPage"

export default function App() {
  return (
    <div className="min-h-svh bg-muted/40">
      <header className="border-b bg-background">
        <div className="mx-auto flex h-14 max-w-3xl items-center justify-between px-4">
          <Link to="/" className="flex items-center gap-2 font-semibold">
            <CheckSquare className="size-5" />
            Task Tracker
          </Link>
          <Button asChild size="sm">
            <Link to="/new">
              <Plus /> New task
            </Link>
          </Button>
        </div>
      </header>
      <main className="mx-auto max-w-3xl px-4 py-8">
        <Routes>
          <Route path="/" element={<TaskListPage />} />
          <Route path="/new" element={<NewTaskPage />} />
          <Route path="/tasks/:id" element={<TaskDetailPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
    </div>
  )
}
